import json
from types import SimpleNamespace
from pathlib import Path
from datetime import datetime
import asyncio
import LibPython
import Bluetooth
from . import BtHome

Logger = LibPython.Logger('Bluetooth.Template')
class Template():
  __All=None
  async def Templates():
    if Template.__All is None:
      Template.__All=await asyncio.get_event_loop().run_in_executor(None,lambda:json.load(open('template.json'), object_hook=lambda x:SimpleNamespace(**x)))
    return Template.__All

  async def Parse(pDevice:Bluetooth.Device,pData:dict[str:bytes])->list[str]:
    if pDevice.Template.ID in ['BTHome','BTHomeV2']: 
      r = await BtHome.Parse(pDevice,pData)
      return r
    _UpdatedEntities=[]
    for _Entity in pDevice.Entities:
      if  _Entity.Characteristic: #This needs connection
        continue
      if not _Entity.Code: continue
      _ServiceData=None
      if hasattr(_Entity,'Service') and _Entity.Service:
        _ServiceData = next((pData[x] for x in pData.keys() if _Entity.Service in x),None)
        if not _ServiceData: continue
      try:
        v = eval(_Entity.Code,None,{'v':_ServiceData})
        _UpdatedEntities.append(_Entity.Name)
        if v: await _Entity.OnValue(v)
      except Exception as x: 
        Logger.Exception(f'Cannot get value for {_Entity.Name}',x)
      return _UpdatedEntities

  async def Get(**kwargs):
    for _Template in await Template.Templates():
      if _Template.ID==LibPython.Utility.DictGet(kwargs,['Type']): 
        return _Template
      if hasattr(_Template.Match,'Name') and _Template.Match.Name==LibPython.Utility.DictGet(kwargs,['Name']): 
        return _Template
      if hasattr(_Template.Match,'Service') and 'Services' in kwargs and kwargs['Services'] is not None:
        ts = _Template.Match.Service if isinstance(_Template.Match.Service,list) else [_Template.Match.Service]
        ds = LibPython.Utility.DictGet(kwargs,['Services'])
        if any(x for x in ds if any(y for y in ts if y.upper() in x.upper())):
          return _Template
    return None

  async def Populate(pDevice:Bluetooth.Device,pType=None,pName=None,pServices=None)->bool:
    pDevice.Template = await Template.Get(Type=pType,Name=pName,Services=pServices)
    if not pDevice.Template: return
    _Entity = Bluetooth.Sensor(Name='Signal',ID='SIGNAL',Device=pDevice,SubType='signal_strength',Enabled=True,Virtual=True)
    pDevice.Entities.Add(_Entity)
    pDevice.SubType = pDevice.Template.ID
    if hasattr(pDevice.Template,'Poll') and pDevice.Template.Poll: pDevice.Poll = datetime.min
    if hasattr(pDevice.Template,'Refresh'): pDevice.RefreshInterval = pDevice.Template.Refresh
    if hasattr(pDevice.Template,'Expiry'): pDevice.ExpiryInterval = pDevice.Template.Expiry
    for e in pDevice.Template.Entities:
      name=e.Name
      id=e.Name.upper()
      subtype = e.SubType if hasattr(e,'SubType') else None
      unit = e.Unit if hasattr(e,'Unit') else None
      service = e.Service if hasattr(e,'Service') else None
      characteristic = e.Characteristic if hasattr(e,'Characteristic') else None
      code = e.Code if hasattr(e,'Code') else None
      _Entity = None
      if e.Type=='Sensor':
        _Entity = Bluetooth.Sensor(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Service=service,Characteristic=characteristic,Code=code)
      elif e.Type=='BinarySensor':
        _Entity = Bluetooth.Button(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Service=service,Characteristic=characteristic,Code=code)
      elif e.Type=='Button':
        _Entity = Bluetooth.Button(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Service=service,Characteristic=characteristic,Code=code)
      elif e.Type=='Switch':
        _Entity = Bluetooth.Switch(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Service=service,Characteristic=characteristic,Code=code)
      elif e.Type=='Number':
        _Entity = Bluetooth.Number(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Service=service,Characteristic=characteristic,Code=code)
      elif e.Type=='text':
        _Entity = Bluetooth.Text(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Service=service,Characteristic=characteristic,Code=code)
      else:
        raise f'Invalid entity configuration {str(e)}'
      _Entity.Enabled = True
      pDevice.Entities.Add(_Entity)
    return True
  
