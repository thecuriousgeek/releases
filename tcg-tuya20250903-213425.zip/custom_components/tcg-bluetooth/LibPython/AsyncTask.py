from datetime import datetime
import atexit
import asyncio
import threading
import contextlib
import gc
from . import Logger
from abc import ABC, abstractmethod

class AsyncTask(ABC):
  def __init__(self,pName:str,pInterval:int=0):
    self.Name = pName
    self.Logger = Logger(f'AsyncTask.{self.Name}')
    self.Interval = pInterval
    self.CommandStop = asyncio.Event()
    self.Loop = asyncio.new_event_loop()
    asyncio.set_event_loop(self.Loop)
    self.Thread = None

  def Start(self):
    self.Thread = threading.Thread(target=self.ThreadStart,args=[],daemon=True,name=self.Name)
    self.Thread.start()

  def ThreadStart(self):
    self.Logger.Info(f'Starting')
    atexit.register(self.Stop)
    self.Loop.run_until_complete(self.StartAsync())

  async def StartAsync(self):
    if not await self.Begin():
      self.Logger.Error('Could not begin task')
      await self.End()
      return
    while not self.CommandStop.is_set():
      self.Logger.Debug('RunBegin')
      _Start = datetime.now()
      _RunResult = False
      try:
        _RunResult = await self.Run()
      except Exception as x:
        self.Logger.Exception('Exception in run',x)
        with contextlib.suppress(asyncio.TimeoutError):
          await asyncio.wait_for(self.CommandStop.wait(),30)
        continue
      self.Logger.Debug('RunEnd')
      if self.CommandStop.is_set(): break
      if not _RunResult: break
      if (datetime.now()-_Start).total_seconds() < self.Interval:
        with contextlib.suppress(asyncio.TimeoutError):
          await asyncio.wait_for(self.CommandStop.wait(),self.Interval)
    self.Logger.Info('Ending')
    await self.End()

  def Stop(self):
    self.Logger.Info('Stopping')
    self.CommandStop.set()
    atexit.unregister(self.Stop)
    self.Thread.join()
    gc.collect()

  @abstractmethod
  async def Run(self)->bool: return False #Returns true if complete so I dont have to force a wait
  async def Begin(self)->bool: return False #May be overridden, returns False if could not begin
  async def End(self): pass #May be overridden

