import os
import time
import ast
import socket
import flask
from flask import jsonify
import logging
from flask.json.provider import DefaultJSONProvider
from . import AsyncTask,Dynamic,Utility

class MyEncoder(DefaultJSONProvider):
  def dumps(self, pObject, **kwargs):
    # return json.dumps(pObject,default=lambda o:o.__dict__ if hasattr(o,'__dict__') else str(o))
    return Utility.ToJson(pObject)

class WebApi(AsyncTask):
  def __init__(self,Port=80,Name='WebAPI',Root='/'):
    self.App = flask.Flask(__name__)
    self.App.template_folder=Root
    self.App.static_folder = self.App.template_folder
    self.Port = Port
    self.App.before_request(self.BeforeRequest)
    self.App.after_request(self.AfterRequest)
    # self.App.add_url_rule('/','DefaultPage',self.GetPage,methods=['GET'])
    self.App.add_url_rule('/','Page',self.GetPage,methods=['GET'])
    self.App.add_url_rule('/<path:pFile>','Page',self.GetPage,methods=['GET'])
    super().__init__(Name)

  def BeforeRequest(self):
    flask.g.start_time = time.perf_counter()
    _Param = flask.request.args
    self.QueryString = Dynamic(CaseSensitive=False)
    for k in _Param.keys():
      v = flask.request.args.getlist(k)
      if len(v)==1: v = v[0]
      if v.startswith(('{','[','(')):
        self.QueryString.Set(k,ast.literal_eval(v))
      else:
        self.QueryString.Set(k,v)
    return None

  def AfterRequest(self,pResponse)->flask.Response:
    total_time = time.perf_counter() - flask.g.start_time
    time_in_ms = int(total_time * 1000)
    if '/api' in flask.request.url:
      self.Logger.Debug(f'{flask.request.method} {flask.request.url} ({pResponse.status_code} in {time_in_ms}ms, {pResponse.content_length} bytes)')
    pResponse.headers['Access-Control-Allow-Origin'] = '*'
    return pResponse
   
  def GetPage(self,pFile:str=None):
    if not pFile or pFile=='/': pFile = 'index.html'
    if not os.path.isfile(self.App.template_folder+'/'+pFile):
      return flask.Response('No such file',404)
    # if pFile.endswith('.html'): return flask.render_template(pFile)   
    return flask.send_file(self.App.static_folder+'/'+pFile)

  def CustomResponse(self,pWhat):
    if pWhat is None:
      return self.OriginalMakeResponse(("",204))
    elif isinstance(pWhat,str):
      return self.OriginalMakeResponse(pWhat)
    elif isinstance(pWhat,flask.wrappers.Response):
      return self.OriginalMakeResponse(pWhat)
    elif isinstance(pWhat,Exception):
      if hasattr(pWhat,'original_exception'):
        return self.OriginalMakeResponse((str(pWhat.original_exception),500))
      else:
        return self.OriginalMakeResponse(pWhat)
    elif isinstance(pWhat,bytes):
      return self.OriginalMakeResponse(pWhat)
    return self.OriginalMakeResponse(jsonify(pWhat))

  async def Begin(self)->bool:
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.ERROR)
    self.OriginalMakeResponse = self.App.make_response
    self.App.make_response = self.CustomResponse
    self.App.json_provider_class = MyEncoder
    self.App.json = MyEncoder(self.App)
    _Socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    for _Port in range(self.Port,self.Port+10):
      try:
        _Socket.bind(('127.0.0.1',_Port))
        _Socket.close()
        self.Port = _Port
        return True
      except Exception: self.Logger.Error(f'Port {_Port} not available')
    return False

  async def Run(self)->bool:
    self.Logger.Info(f'Web server listening on {self.Port}')
    self.App.run(host='0.0.0.0',port=self.Port)
    return False
