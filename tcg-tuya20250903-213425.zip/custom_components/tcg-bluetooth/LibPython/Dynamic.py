import json
from .Utility import ToJson

class Dynamic(dict[str:any]):
  def __init__(self,From:str|dict[str,any]=None,CaseSensitive=True,**kwargs):
    # self._CaseSensitive=CaseSensitive
    self.__dict__['_CaseSensitive']=CaseSensitive #Important since we override getattr
    if isinstance(From,str):
      if From=='': return
      _Dict = json.loads(From)
      self.__init__(_Dict,CaseSensitive=CaseSensitive,**kwargs)
    elif isinstance(From,dict):
      for n,v in From.items():
        if isinstance(v, (list, tuple)):
          setattr(self, str(n), [Dynamic(x) if isinstance(x, dict) else x for x in v])
        else:
          setattr(self, str(n), Dynamic(v) if isinstance(v, dict) else v)
    elif isinstance(From,Dynamic):
      for n,v in From.items():
        self[n] = v
    elif kwargs:
      for n,v in kwargs.items():
        self[n] = v
 
  @property
  def CaseSensitive(self)->bool:
    return self._CaseSensitive
  
  @property
  def Fields(self)->list[str]:
    return list(self.keys())
  
  def Contains(self,Field:str)->bool:
    if self._CaseSensitive: return any(x for x in self.keys() if x==Field)
    return any(x for x in self.keys() if x.upper()==Field.upper())
    
  def __getattr__(self,pName:str):
    if self._CaseSensitive: return self[pName] if pName in self.keys() else None
    return next((self[x] for x in self.keys() if x.upper()==pName.upper()),None)

  def __setattr__(self,pName:str,pValue):
    self[pName if self._CaseSensitive else pName.upper()] = pValue
    
  def Get(self,pName:str):
    return self.__getattr__(pName if self._CaseSensitive else pName.upper())
  
  def Set(self,pName:str, pValue):
    self[pName if self._CaseSensitive else pName.upper()] = pValue

  def __repr__(self):
    return ToJson(self)
  
  def __eq__(self,pOther)->bool:
    if not isinstance(pOther,dict): 
      return False
    for a in self.keys():
      if not a in pOther.keys(): return False
      if not self[a]==pOther[a]: return False
    return True
  
  def __ge__(self,pOther)->bool:
    for a in self.keys():
      if hasattr(pOther,a) and not self[a]==pOther[a]: return False
    return True  

  def Merge(self,pWhat):
    if not isinstance(pWhat,Dynamic): raise ('Dynamic:Invalid object to merge')
    for _Field in pWhat.Fields:
      if self.Contains(_Field):
        if isinstance(self[_Field],list):
          if isinstance(pWhat[_Field],list): 
            self[_Field].extend([x for x in pWhat[_Field] if not x in self[_Field]])
          elif isinstance(pWhat[_Field],Dynamic):
            self[_Field] = pWhat[_Field] #Destructive merge
          elif not pWhat[_Field] in self[_Field]: self[_Field].append(pWhat[_Field])
        elif isinstance(self[_Field],Dynamic) and isinstance(pWhat[_Field],Dynamic):
          self[_Field].Merge(pWhat[_Field])
        elif isinstance(self[_Field],dict) and isinstance(pWhat[_Field],dict):
          for k,v in pWhat[_Field].items():
            self[_Field][k] = v
        elif type(self[_Field])==type(pWhat[_Field]):
          if not self[_Field]==pWhat[_Field]: self[_Field] = [self[_Field],pWhat[_Field]]
        else:
          self[_Field] = [self[_Field],pWhat[_Field]]
      else:
        if isinstance(pWhat[_Field],list): #Python copies lists by reference
          self[_Field]=[]+pWhat[_Field]
        else:
          self[_Field] = pWhat[_Field]
