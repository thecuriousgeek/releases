import os
from datetime import datetime
import asyncio
import tracemalloc
import flask 
from flask import request
import psutil
import json
import LibPython
import tracemalloc
import gc
import LibHass

class WebApi(LibPython.WebApi):
  def GetUsage(self):
    _Process = psutil.Process(os.getpid())
    _Result=LibPython.Dynamic()
    _Result.When = datetime.now()
    _Result.When=datetime.now()
    _Result.Memory=_Process.memory_info().rss
    _Result.Snapshot=tracemalloc.take_snapshot()
    _Result.Connections=[x for x in _Process.net_connections(kind='inet') if x.raddr and x.status]
    _Result.Handles=_Process.num_handles() if os.name=='nt' else len(os.listdir('/proc/self/fd'))
    _Result.Threads=_Process.num_threads()
    return _Result

  def __init__(self,pPlatform):
    self.Platform = pPlatform
    gc.collect()
    tracemalloc.start()
    self.LastUsage = self.GetUsage()
    super().__init__(Root=f'{os.path.dirname(__file__)}/Web')
    self.App.add_url_rule('/api/device/<pID>','GetDevice',self.GetDevice,methods=['GET'])
    self.App.add_url_rule('/api/device/<pID>','SetDevice',self.SetDevice,methods=['PUT'])
    self.App.add_url_rule('/api/refresh/<pID>','Refresh',self.Refresh,methods=['GET'])
    self.App.add_url_rule('/api/register/<pID>','Register',self.Register,methods=['POST','DELETE'])
    self.App.add_url_rule('/api/restart/<pType>','Restart',self.Restart,methods=['GET'])
    self.App.add_url_rule('/api/devices','Devices',self.GetDevices,methods=['GET'])
    self.App.add_url_rule('/api/reload','Reload',self.Reload,methods=['GET'])
    self.App.add_url_rule('/api/system','System',self.System,methods=['GET'])
    self.App.add_url_rule('/log/<pLevel>','Log',self.Log,methods=['GET'])

  async def Reload(self)->None:
    await self.Platform.Reload()
    return "Done"

  async def Refresh(self,pID:str=None)->None:
    if pID:
      d = self.Platform.Devices.Get(pID)
      if d and d.Monitor: asyncio.run_coroutine_threadsafe(d.Monitor.Refresh(),d.Monitor.Loop)
    else:
      for d in p.Devices:
        asyncio.run_coroutine_threadsafe(d.Monitor.Refresh(),d.Monitor.Loop)
    return "Done"

  async def Restart(self,pType:str=None)->None:
    await self.Platform.Restart()
    return "Done"

  async def System(self):
    gc.collect()
    _Usage = self.GetUsage()
    #Result
    _Result = LibPython.Dynamic()
    _Result.Period = f'Between {str(self.LastUsage.When.strftime("%Y-%m-%d %H:%M:%S"))} and {str(_Usage.When.strftime("%Y-%m-%d %H:%M:%S"))}' 
    #Memory
    _Result.Memory = LibPython.Dynamic(Current=_Usage.Memory/1024/1024,Delta=(_Usage.Memory-self.LastUsage.Memory)/1024/1024)
    #Handles & Threads
    _Result.Handles = LibPython.Dynamic(Current=_Usage.Handles,Delta=(_Usage.Handles-self.LastUsage.Handles))
    _Result.Threads = LibPython.Dynamic(Current=_Usage.Threads,Delta=(_Usage.Threads-self.LastUsage.Threads))
    #Tracemalloc
    _Result.MemoryAllocation = LibPython.Dynamic(Current=[],Delta=[])
    _TopStats = _Usage.Snapshot.statistics('lineno')
    for stat in _TopStats[:20]:
        _Result.MemoryAllocation.Current.append(str(stat))
    _TopStats = _Usage.Snapshot.compare_to(self.LastUsage.Snapshot, 'lineno')
    for stat in _TopStats[:20]:
        _Result.MemoryAllocation.Delta.append(str(stat))
    #Connections
    _Add = set(_Usage.Connections) - set(self.LastUsage.Connections)
    _Del = set(self.LastUsage.Connections) - set(_Usage.Connections)
    _Result.Connections = LibPython.Dynamic()
    _Result.Connections.All = {f'{x.raddr.ip},{x.raddr.port}':x.status for x in _Usage.Connections}
    _Result.Connections.Added = {f'{x.raddr.ip},{x.raddr.port}':x.status for x in _Add}
    _Result.Connections.Removed = {f'{x.raddr.ip}:{x.raddr.port}':x.status for x in _Del}
    self.LastUsage = _Usage
    return _Result

  async def Log(self,pLevel:str=''):
    if pLevel.upper()=='DEBUG': LibPython.Logger.SetLevel(LibPython.Logger.LEVEL.DEBUG)
    elif pLevel.upper()=='INFO': LibPython.Logger.SetLevel(LibPython.Logger.LEVEL.INFO)
    elif pLevel.upper()=='WARNING': LibPython.Logger.SetLevel(LibPython.Logger.LEVEL.WARNING)
    elif pLevel.upper()=='ERROR': LibPython.Logger.SetLevel(LibPython.Logger.LEVEL.ERROR)
    elif pLevel.upper()=='CRITICAL': LibPython.Logger.SetLevel(LibPython.Logger.LEVEL.CRITICAL)
    return flask.Response(f'Log level set to {pLevel.upper()}',200)

  def _GetDevice(self,pID:str)->LibHass.Device:
    d = self.Platform.Devices.Get(pID)
    if d: return d
    return None

  def GetDevice(self,pID:str):
    _Device = self._GetDevice(pID)
    if _Device:
      return LibPython.Dynamic(Type=_Device.Type, Name=_Device.Name, ID=_Device.ID, Updated=_Device.Updated, Refreshed=_Device.Refreshed, Entities=[LibPython.Dynamic(Type=x.Type, Name=x.Name, ID=x.ID, Value=x.Value, Updated=x.Updated, Command=hasattr(x,'OnCommand')) for x in _Device.Entities])
    return flask.abort(404)

  async def SetDevice(self,pID:str):
    if not request.is_json: return flask.abort(406,'Invalid data provided') 
    _Device = self._GetDevice(pID)
    if not _Device: return flask.abort(404,'No such device')
    if not _Device.IsConnected: return flask.abort(404,'Device not connected')
    d = json.loads(request.data)
    e = d['Entity']
    _Entity = _Device.Entities.Get(e['ID'])
    if not _Entity: return flask.abort(404,'No such entity')
    try:
      if isinstance(_Entity,LibHass.Switch):
        asyncio.run_coroutine_threadsafe(_Entity.OnCommand(e['Value'].upper() in ['1','ON','TRUE']),LibHass.MainLoop)
      elif isinstance(_Entity,LibHass.Button):
        asyncio.run_coroutine_threadsafe(_Entity.OnCommand(),LibHass.MainLoop)
      elif isinstance(_Entity,LibHass.Number):
        asyncio.run_coroutine_threadsafe(_Entity.OnCommand(int(e['Value'])),LibHass.MainLoop)
      else:
        asyncio.run_coroutine_threadsafe(_Entity.OnCommand(e['Value']),LibHass.MainLoop)
      return 'OK'
    except Exception as x:
      return flask.abort(500,str(x))

  def GetDevices(self):
    _Result = []
    _Devices = []
    for d in self.Platform.Devices:
      _Device = LibPython.Dynamic()
      _Device.Name = d.Name
      _Device.ID = d.ID
      _Device.Type = d.Type
      _Device.SubType = d.Template.Name if d.Template else d.SubType
      _Device.IsRegistered = d.IsRegistered
      _Device.IsDetected = d.Detected>datetime.min
      _Device.IsConnected = d.IsConnected
      _Device.Updated = d.Updated.strftime('%H:%M:%S')
      _Device.Detected = d.Detected.strftime('%H:%M:%S')
      _Device.Connected = d.Connected.strftime('%H:%M:%S')
      _Device.Refreshed = d.Refreshed.strftime('%H:%M:%S')
      _Device.Entities = str(d.Entities)
      _Result.append(_Device)
    _Result.sort(key=lambda d:d.Updated,reverse=True)
    return _Result

  async def Register(self,pID:str):
    _Device = self._GetDevice(pID)
    if flask.request.method=='DELETE':
      if not _Device: return flask.abort(404,'No such device')
      if not _Device.IsRegistered: return flask.abort(404,'Device not registered')
      self.Platform.Remove(_Device)
      if _Device.IsConnected: await _Device.Disconnect()
      return f'{_Device.Name} deregistered'
    elif flask.request.method=='POST':
      if not _Device: return flask.abort(404,'No such device')
      if  _Device.IsRegistered: return flask.abort(404,'Device already registered')
      self.Platform.Add(_Device)
      return f'{_Device.Name} registered'
    return flask.abort(405)
