import asyncio
Hass=None
MainLoop=None
IS_ADDON=False
try:
  from homeassistant import core
  IS_ADDON=True
except:
  pass

from datetime import datetime
import atexit
from threading import Thread,Event


from .Device import Device,DeviceCollection
from .Entity import *
from . import Component
from .WebApi import WebApi
