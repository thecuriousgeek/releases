import asyncio
from tinytuya import Device as TinyTuyaDevice
import LibPython
import LibHass
import Tuya

class Device(LibHass.Device):
  @staticmethod
  async def Remove(pID:str)->None:
    _Device =  Tuya.Devices.Get(pID)
    if _Device: 
      Tuya.Devices.remove(_Device)
    return

  @staticmethod
  async def GetOrCreate(**kwargs):
    _Device =  Tuya.Devices.Get(kwargs['ID'])
    if not _Device: 
      _Device = Device(**kwargs)
      await Tuya.Template.Populate(_Device,_Device.SubType)
      Tuya.Devices.Add(_Device)
    return _Device
 
  def __init__(self,**kwargs):
    LibHass.Device.__init__(self,**kwargs)
    self.Monitor = None
    self.SubType = self.SubType or LibPython.Utility.DictGet(kwargs,['category'])
    self.__Gateway = LibPython.Utility.DictGet(kwargs,['gateway_id','Gateway'])    
    self.NodeID = LibPython.Utility.DictGet(kwargs,['node_id','NodeID'])
    self.LocalKey = LibPython.Utility.DictGet(kwargs,['key','LocalKey'])
    self.MacID = LibPython.Utility.DictGet(kwargs,['mac','MacID'])
    self.Product = LibPython.Utility.DictGet(kwargs,['product_name','Product'])
    self.Model = LibPython.Utility.DictGet(kwargs,['model','Model'])
    self.Icon = LibPython.Utility.DictGet(kwargs,['icon','Icon'])
    dp = kwargs['dp'] if 'dp' in kwargs else kwargs
    self.Function = LibPython.Utility.DictGet(dp,['functions','Function'])
    self.Status = LibPython.Utility.DictGet(dp,['status','Status'])
    self.IP = None #Set by Scanner on detection
    self.Version = None #Set by Scanner on detection

  @property
  def IsGateway(self)->bool:
    return any(x for x in Tuya.Devices if x.__Gateway and x.__Gateway.upper()==self.ID.upper())

  @property
  def SubDevices(self)->list:
    return [x for x in Tuya.Devices if x.__Gateway and x.__Gateway.upper()==self.ID.upper()]

  @property
  def IsSubDevice(self)->bool:
    return True if self.__Gateway else False

  @property
  def Gateway(self):
    if not self.__Gateway: return None
    return Tuya.Devices.Get(self.__Gateway)

  # @property
  # def Configuration(self)->dict[str:str]:
  #   _Result = {}
  #   _Result['SubType'] = self.SubType
  #   _Result['Gateway'] = self.Gateway
  #   _Result['NodeID'] = self.NodeID
  #   _Result['LocalKey'] = self.LocalKey
  #   _Result['MacID'] = self.MacID
  #   _Result['Product'] = self.Product
  #   _Result['Model'] = self.Model
  #   _Result['Icon'] = self.Icon
  #   _Result['Function'] = self.Function
  #   _Result['Status'] = self.Status
  #   for k,v in BaseDevice.Configuration.fget(self).items():
  #     _Result[k] = v
  #   return _Result

  @property
  def IsConnected(self)->bool:
    return self.Monitor is not None

  async def OnDetect(self)->None:
    # if self.IsConnected: return
    # if not self.Entities.Get('MACID').Value==self.MacID: await self.Entities.Get('MACID').OnValue(self.MacID)
    # if not self.Entities.Get('VERSION').Value==self.Version: await self.Entities.Get('VERSION').OnValue(self.Version)
    await LibHass.Device.OnDetect(self)

  async def Connect(self)->bool:
    if self.Monitor or self.IsGateway: return True
    self.Monitor = Tuya.Monitor(self)
    self.Monitor.Start()
    return True

  async def Disconnect(self)->None:
    if self.Monitor:
      asyncio.run_coroutine_threadsafe(self.Monitor.Disconnect(),self.Monitor.Loop)
    else:
      asyncio.run_coroutine_threadsafe(self.OnDisconnect(),LibHass.MainLoop)

  async def OnDisconnect(self)->None:
    if self.Monitor: 
      self.Monitor.Stop()
    self.Monitor = None
    await LibHass.Device.OnDisconnect(self)

  async def Refresh(self):
    if self.Monitor: 
      asyncio.run_coroutine_threadsafe(self.Monitor.Refresh(),self.Monitor.Loop)
