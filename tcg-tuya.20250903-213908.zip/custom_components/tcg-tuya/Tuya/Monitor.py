from datetime import datetime
import asyncio
from tinytuya import Device as TinyTuyaDevice
import LibPython
import LibHass
import Tuya

class Monitor(LibPython.AsyncTask):
  def __init__(self,pDevice:Tuya.Device):
    super().__init__(f'Tuya.Monitor.{pDevice.Name}')
    self.Device = pDevice
    self.Client = None
    self.HeartBeat = datetime.min
    # self.Device.RefreshInterval = 30

  async def Begin(self)->bool:
    self.Device.Updated = datetime.min #I want to refresh the first time
    if self.Device.IsSubDevice:
      _Parent = self.Device.Gateway
      self.Client = TinyTuyaDevice(_Parent.ID,address=_Parent.IP,local_key=_Parent.LocalKey,version=float(_Parent.Version),cid=self.Device.NodeID)
    else:
      self.Client = TinyTuyaDevice(self.Device.ID,address=self.Device.IP,local_key=self.Device.LocalKey,version=float(self.Device.Version))
    # self.Client = TinyTuyaDevice(self.Device.ID,address=self.Device.IP,local_key=self.Device.LocalKey,version=float(self.Device.Version))
    if not self.Client: return False
    if not self.Device.IsSubDevice:
      asyncio.run_coroutine_threadsafe(self.Device.Entities.Get('IP').OnValue(self.Device.IP),LibHass.MainLoop)
    self.Client.set_socketPersistent(True)
    asyncio.run_coroutine_threadsafe(self.Device.OnConnect(),LibHass.MainLoop)
    # for _Child in self.Device.SubDevices:
    #   _Child.Monitor = self
    #   asyncio.run_coroutine_threadsafe(BaseDevice.OnConnect(_Child),LibHass.MainLoop)
      
    return True

  async def Run(self)->bool:
    if not self.Client: return False
    _Data = self.Client.receive()
    if _Data: 
      if 'Err' in _Data and not _Data['Err']=='904': 
        self.Logger.Warning(f'Network error in receive:{str(_Data)}')
        return False
      if 'dps' in _Data:
        self.UpdateEntities(_Data)
      return True
    if (datetime.now()-self.HeartBeat).total_seconds()>10: 
      self.Client.heartbeat()
      self.HeartBeat = datetime.now()
    if (datetime.now()-self.Device.Refreshed).total_seconds()>self.Device.RefreshInterval:
      self.Logger.Info(f'Not updated since {str(self.Device.Refreshed)}, Refreshing')
      return await self.Refresh()
    if (datetime.now()-self.Device.Refreshed).total_seconds()>self.Device.ExpiryInterval:
      self.Logger.Warning(f'Not updated since {str(self.Device.Refreshed)}, Disconnecting')
      return False
    await asyncio.sleep(1.0)    
    return True

  async def End(self)->None:
    if self.Client: self.Client.close()
    self.Client = None
    if self.Device.IsGateway:
      for _SubDevice in self.Device.SubDevices:
        asyncio.run_coroutine_threadsafe(_SubDevice.OnDisconnect(),LibHass.MainLoop)
    asyncio.run_coroutine_threadsafe(self.Device.OnDisconnect(),LibHass.MainLoop)

  async def Disconnect(self)->None:
    if self.Client: self.Client.close()
    self.Client = None
    if self.Device.IsGateway:
      for _SubDevice in self.Device.SubDevices:
        asyncio.run_coroutine_threadsafe(_SubDevice.OnDisconnect(),LibHass.MainLoop)
    asyncio.run_coroutine_threadsafe(self.Device.OnDisconnect(),LibHass.MainLoop)

  async def Refresh(self)->bool:
    if self.Device.IsGateway:
      # _ChildStatus = self.Client.subdev_query()      
      # if _ChildStatus and 'data' in _ChildStatus:
      #   if 'online' in _ChildStatus['data']: 
      #     for d in _ChildStatus['data']['online']:
      #       _Child = Devices.GetNode(d)
      #       if not _Child: continue
      #       if not _Child.Monitor:
      #         _Child.Monitor = self
      #         asyncio.run_coroutine_threadsafe(BaseDevice.OnConnect(_Child),LibHass.MainLoop)
      #       asyncio.run_coroutine_threadsafe(BaseDevice.OnRefresh(_Child),LibHass.MainLoop)
      #   if 'offline' in _ChildStatus['data']: 
      #     for d in _ChildStatus['data']['offline']:
      #       _Child = Devices.GetNode(d)
      #       if not _Child: continue
      #       if _Child.Monitor:
      #         _Child.Monitor = None
      #         asyncio.run_coroutine_threadsafe(BaseDevice.OnDisConnect(_Child),LibHass.MainLoop)
      asyncio.run_coroutine_threadsafe(LibHass.Device.OnRefresh(self.Device),LibHass.MainLoop)
      return True
    # elif self.Device.IsSubDevice:
    #   asyncio.run_coroutine_threadsafe(BaseDevice.OnRefresh(self.Device),LibHass.MainLoop)
      # return True
    _Status = self.Client.status()
    if not _Status:
      return True
    if 'Err' in _Status:
      self.Logger.Warning(f'Network error in status:{str(_Status)}')
      return False
    _UpdatedEntities = self.UpdateEntities(_Status)
    asyncio.run_coroutine_threadsafe(LibHass.Device.OnRefresh(self.Device),LibHass.MainLoop)
    return True
 
  def UpdateEntities(self,pStatus):
    _UpdatedEntities=[]
    if not 'dps' in pStatus:
      return _UpdatedEntities
    if 'Payload' in pStatus and not pStatus['Payload']: #Try again in next cycle with just receive
      self.Logger.Warning(f'No Payload:{str(pStatus)}')
      return _UpdatedEntities
    self.Device.Updated = datetime.now()
    _Device = self.Device
    if 'cid' in pStatus:
      _Device = Tuya.Devices.GetNode(pStatus['cid'])
      if not _Device: return _UpdatedEntities
    for k,v in pStatus['dps'].items():
      e = _Device.Entities.Get(k)
      if not e: continue
      asyncio.run_coroutine_threadsafe(e.OnValue(v),LibHass.MainLoop)
      _UpdatedEntities.append(e.Name)
    _Device.Logger.Info(f'Updated:{len(_UpdatedEntities)} entities ({','.join(_UpdatedEntities)})')
    return _UpdatedEntities
    