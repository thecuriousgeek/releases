import LibPython
import LibHass 
import os
import json
import asyncio
import tinytuya
from .Device import Device
from .Entity import *
from .Template import Template
from . import Scanner
from .Monitor import Monitor

Name='tcg-tuya'
ApiKey=None
Secret=None
Region=None
ConfiguredDevices=LibHass.DeviceCollection()
Devices = LibHass.DeviceCollection()
CloudDevices = {}

async def Reload()->None:
  os.remove('cloud.json')
  asyncio.run_coroutine_threadsafe(Load(),loop=LibHass.MainLoop)
  
async def Restart()->None:
  import Scanner
  Scanner.Stop()
  for d in Devices:
    if d.IsConnected: asyncio.run_coroutine_threadsafe(d.Disconnect(),LibHass.MainLoop)
  Scanner.Start()
  
async def Init():
  pass

def Configuration()->dict:
  _Result = {}
  _Result['ApiKey'] = ApiKey
  _Result['Secret'] = Secret
  _Result['Region'] = Region
  _Devices = [{'ID':x.ID,'Name':x.Name} for x in Devices if x.IsRegistered]
  #Because Im OCD
  _Result['Devices'] = sorted(_Devices, key=lambda i: i['Name'])
  return _Result

async def Configure(pData:dict):
  if not pData:
    pData = await LoadConfig()
    if not pData: raise 'No configuration found'
  global ApiKey,Secret,Region,User,Password
  ApiKey = pData['ApiKey'] if 'ApiKey' in pData else None
  Secret = pData['Secret'] if 'Secret' in pData else None
  Region = pData['Region'] if 'Region' in pData else None
  await Load()
  ConfiguredDevices.clear()
  for d in pData['Devices'] or [] if 'Devices' in pData else []:
    await Device.Remove(d['ID'])
    _Device = await Device.GetOrCreate(ID=d['ID'],Name=d['Name'],**CloudDevices[d['ID']])
    ConfiguredDevices.Add(_Device)
    _Device.IsRegistered = True

async def Load():
  Logger = LibPython.Logger('Tuya.Load')
  _Data = []
  if os.path.exists('cloud.json'):# and os.stat('cloud.json').st_mtime>time.time()-43200:
    Logger.Debug(f'Loading cached data')
    _Data = await asyncio.get_event_loop().run_in_executor(None,lambda:json.load(open('cloud.json','r')))
    # json.load(open('cloud.json','r'))
  else:
    Logger.Debug(f'Retrieving from cloud')
    if LibHass.IS_ADDON: _Data = await LibHass.Hass.async_add_executor_job(LoadFromCloud)
    else: _Data = LoadFromCloud()
    json.dump(_Data,open('cloud.json','w'),indent=2)
  Logger.Debug(f'Loaded {len(_Data)} devices')
  CloudDevices.clear()
  for d in _Data:
    CloudDevices[d['id'].upper()] = d
    await Device.GetOrCreate(ID=d['id'],Name=d['name'],**d)

def LoadFromCloud():
  _Data=[]
  t = tinytuya.Cloud(apiRegion=Region,apiKey=ApiKey,apiSecret=Secret)
  l = t.getdevices()
  for d in l:
    p = t.getdps(d['id'])
    if 'result' in p: 
      d['dp'] = p['result']
    else:
      d['dp'] = {'status':[],'functions':[]}
    _Data.append(d)
  return _Data

async def LoadConfig()->dict:
  if not os.path.exists('config.json'): return
  _Data = json.load(open('config.json','r'))
  return _Data

async def Save():
  _Devices = Configuration()
  s = json.dumps(_Devices,default=lambda o: o.__dict__,indent=2)
  open('config.json','w').write(s)

def Add(pDevice)->bool:
  pDevice.IsRegistered = True
  Save()

def Remove(pDevice)->bool:
  pDevice.IsRegistered = False
  Save()

def Save():
  _Devices = Configuration()
  s = json.dumps(_Devices,default=lambda o: o.__dict__,indent=2)
  open('config.json','w').write(s)
