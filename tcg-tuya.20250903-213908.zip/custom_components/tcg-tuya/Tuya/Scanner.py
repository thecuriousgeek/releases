import tinytuya.scanner
from datetime import datetime
import LibPython
import Tuya

SCAN_INTERVAL=10
class Scanner(LibPython.AsyncTask):     
  def __init__(self):
    super().__init__('Scanner',30)

  async def Begin(self)->bool:
    return True
  
  async def End(self):
    for d in Tuya.Devices:
      if d.IsConnected: await d.Disconnect()

  async def Run(self)->None:
    _ScanResult = tinytuya.scanner.devices(verbose=False,poll=False)
    pass
    for _ScanData in _ScanResult.values():
      _Device = Tuya.Devices.Get(_ScanData['id'])
      if not _Device:
        #self.Logger.Warning(f'Unknown device detected {str(_ScanData)}')
        continue
      _Device.Detected = datetime.now()
      _Device.IP = _ScanData['ip']
      _Device.Version = _ScanData['version']
      self.Logger.Debug(f'Detected {_Device.Name}')
      if _Device.IsRegistered:
        await _Device.OnDetect()
      if _Device.IsGateway:
        for _SubDevice in _Device.SubDevices:
          self.Logger.Debug(f'Detected SubDevice {_SubDevice.Name}')
          _Device.Detected = datetime.now()
          _Device.IP = _ScanData['ip']
          _Device.Version = _ScanData['version']
          if _SubDevice.IsRegistered: await _SubDevice.OnDetect()
    return True

_Instance = None
def Start():
  global _Instance
  if _Instance: _Instance.Stop()
  _Instance = Scanner()
  _Instance.Start()

def Stop():
  global _Instance
  if _Instance: _Instance.Stop()
  _Instance = None
  