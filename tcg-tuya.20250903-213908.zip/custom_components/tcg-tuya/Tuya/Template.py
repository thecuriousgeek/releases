import json
from types import SimpleNamespace
import asyncio
import LibPython
import Tuya

Logger = LibPython.Logger('Tuya.Template')
class Template():
  __All = None
  async def Templates():
    if Template.__All is None:
      Template.__All=await asyncio.get_event_loop().run_in_executor(None,lambda:json.load(open('template.json'), object_hook=lambda x:SimpleNamespace(**x)))
    return Template.__All
  
  async def Populate(pDevice:Tuya.Device,pType=None)->bool:
    if not pDevice.IsSubDevice:
      pDevice.Entities.Add(Tuya.Sensor(ID='IP',Name='IP',Device=pDevice,Enabled=True,Virtual=True))
      pDevice.Entities.Add(Tuya.Sensor(ID='MACID',Name='MacID',Device=pDevice,Virtual=True))
      pDevice.Entities.Add(Tuya.Sensor(ID='VERSION',Name='Version',Device=pDevice,Virtual=True))
    for e in pDevice.Status:
      if any(x['dp_id']==e['dp_id'] for x in pDevice.Function): 
        continue #Will handle as a 'writeable' entity
      _Entity = None
      name = e['code']
      id = str(e['dp_id'])
      subtype = None
      unit = None
      scale = None
      if e['type']=='Integer':
        if 'values' in e and e['values']:
          v = json.loads(e['values'])
          unit = v['unit'] if 'unit' in v else None
          scale = 10**v['scale'] if 'scale' in v else None
        _Entity = Tuya.Sensor(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Scale=scale)
      elif e['type']=='Raw':
        _Entity = Tuya.RawSensor(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Scale=scale)
      elif e['type']=='String' or e['type']=='Enum':
        _Entity = Tuya.Sensor(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Scale=scale)
      elif e['type']=='Boolean':
        _Entity = Tuya.BinarySensor(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Scale=scale)
      else: 
        continue
      pDevice.Entities.Add(_Entity)
    for e in pDevice.Function:
      _Entity = None
      name = e['code']
      id = str(e['dp_id'])
      subtype = None
      unit = None
      scale = None
      if e['type']=='Boolean':
        _Entity = Tuya.Switch(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Scale=scale)
      elif e['type']=='Integer':
        _Entity = Tuya.Number(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Scale=scale)
      elif e['type']=='String':
        _Entity = Tuya.Text(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Scale=scale)
      elif e['type']=='Raw':
        _Entity = Tuya.Text(ID=id,Name=name,Device=pDevice,SubType=subtype,Unit=unit,Scale=scale)
      else: 
        continue
      pDevice.Entities.Add(_Entity)
    pDevice.Template = next((x for x in await Template.Templates() if x.ID==pType),None)
    if not pDevice.Template: return True
    if not hasattr(pDevice.Template,'Entities'): pDevice.Template.Entities = []
    for e in pDevice.Template.Entities:
      if hasattr(e,'ID'): #Enabling an existing entity
        _Entity = pDevice.Entities.Get(e.ID)
        if _Entity:
          _Entity.Enabled = True
          if hasattr(e,'Name'): _Entity.Name = e.Name
        continue
      if not hasattr(e,'Parent'): continue #Cant have an entity without a parent
      _Entity = None
      name = e.Name
      id = e.Name
      parent = pDevice.Entities.Get(e.Parent)
      if not parent:
        continue #raise f'Parent not defined: {str(e)}'
      subtype = e.SubType if hasattr(e,'SubType') else None
      unit = e.Unit if hasattr(e,'Unit') else None
      code = e.Code if hasattr(e,'Code') else None
      if e.Type=='Sensor':
        _Entity = Tuya.Sensor(ID=id,Name=name,Parent=parent,Device=pDevice,SubType=subtype,Unit=unit,Code=code)
      elif e.Type=='BinarySensor':
        _Entity = Tuya.BinarySensor(ID=id,Name=name,Parent=parent,Device=pDevice,SubType=subtype,Unit=unit,Code=code)
      elif e.Type=='Button':
        _Entity = Tuya.Button(ID=id,Name=name,Parent=parent,Device=pDevice,SubType=subtype,Unit=unit,Code=code)
      elif e.Type=='Switch':
        _Entity = Tuya.Switch(ID=id,Name=name,Parent=parent,Device=pDevice,SubType=subtype,Unit=unit,Code=code)
      elif e.Type=='Number':
        _Entity = Tuya.Number(ID=id,Name=name,Parent=parent,Device=pDevice,SubType=subtype,Unit=unit,Code=code)
      elif e.Type=='String':
        _Entity = Tuya.Text(ID=id,Name=name,Parent=parent,Device=pDevice,SubType=subtype,Unit=unit,Code=code)
      elif e.Type=='Energy':
        _Entity = Tuya.Energy(ID=id,Name=name,Parent=parent,Device=pDevice,SubType=subtype,Unit=unit,Code=code)
      else:
        continue #raise f'Invalid entity configuration. Invalid Type:{str(e)}'
      _Entity.Enabled = True
      pDevice.Entities.Add(_Entity)
    return True
