import base64
# from tuya_iot import TUYA_LOGGER, TuyaOpenAPI, TuyaOpenMQ, AuthType, TuyaAssetManager, TuyaDeviceManager, TuyaDevice
import asyncio
import LibPython
import LibHass

class Entity(LibHass.Entity):
  def __init__(self,**kwargs):
    LibHass.Entity.__init__(self,**kwargs)
    self.SubType = LibPython.Utility.DictGet(kwargs,['SubType'])
    self.Unit = LibPython.Utility.DictGet(kwargs,['Unit'])
    self.Code = LibPython.Utility.DictGet(kwargs,['Code'])


class Sensor(Entity,LibHass.Sensor):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Sensor.__init__(self,**kwargs)
    self.Scale = kwargs['Scale'] if 'Scale' in kwargs else None

  async def OnValue(self,pValue):
    await LibHass.Sensor.OnValue(self,pValue/self.Scale if pValue and self.Scale else pValue)


class RawSensor(Entity,LibHass.Sensor):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Sensor.__init__(self,**kwargs)

  async def OnValue(self,pValue):
    await LibHass.Sensor.OnValue(self,base64.b64decode(pValue) if pValue else pValue)


class BinarySensor(Entity,LibHass.BinarySensor):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.BinarySensor.__init__(self,**kwargs)


class Button(Entity,LibHass.Button):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Button.__init__(self,**kwargs)


class Switch(Entity,LibHass.Switch):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Switch.__init__(self,**kwargs)

  async def OnCommand(self,pCommand:bool):
    if not self.Device or not self.Device.IsConnected:
      raise 'Device not connected'
    _Command=pCommand
    if self.Code: #Custom code to send
      try:
        _Command = eval(self.Code,{'v':pCommand})
      except Exception as x:
        self.Logger.Error('Cannot send command')
    LibHass.MainLoop.run_in_executor(None,lambda:self.Device.Monitor.Client.set_value(self.Parent.ID if self.Parent else self.ID,_Command,True))
    await self.OnValue(pCommand)


class Text(Entity,LibHass.Text):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Text.__init__(self,**kwargs)

  async def OnCommand(self,pCommand:str):
    await self.OnValue(pCommand)
    if self.Device and self.Device.IsConnected:
      LibHass.MainLoop.run_in_executor(None,lambda:self.Device.Client.set_value(self.ID,self.Value,True))


class Number(Entity,LibHass.Number):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Number.__init__(self,**kwargs)

  async def OnCommand(self,pCommand:int):
    await self.OnValue(pCommand)
    if self.Device and self.Device.IsConnected:
      LibHass.MainLoop.run_in_executor(None,lambda:self.Device.Client.set_value(self.ID,self.Value,True))


class Energy(Entity,LibHass.Energy):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Energy.__init__(self,**kwargs)
