import asyncio
from datetime import datetime
from bleak import BleakClient
from homeassistant.components import bluetooth
from homeassistant.components.bluetooth import BluetoothScanningMode,BluetoothServiceInfoBleak,async_ble_device_from_address
import LibPython
import LibHass
import Bluetooth

SCAN_INTERVAL=10
class Scanner(LibPython.AsyncTask):
  _Events=None
  _Scanner=None
  _Done=[]

  def __init__(self):
    super().__init__('Bluetooth.HassScanner')

  async def Begin(self):
    self._Scanner = bluetooth.async_register_callback(LibHass.Hass,self.OnDetect,{},bluetooth.BluetoothScanningMode.ACTIVE)
    self._Events = [asyncio.create_task(self.CommandStop.wait())]
    return True

  async def End(self):
    self._Scanner #To remove the callback
    return True

  def GetClient(pID:str,pOnDisconnect):
    return BleakClient(pID,disconnected_callback=pOnDisconnect,timeout=60)

  def OnDetect(self,pDevice,pType):
    asyncio.run_coroutine_threadsafe(self._OnDetect(pDevice,pType),self.Loop)

  async def _OnDetect(self,pDevice,pType):
    _Device = await Bluetooth.Device.GetOrCreate(
              ID=pDevice.address,
              Name=pDevice.name,
              Services=pDevice.service_uuids if len(pDevice.service_uuids)>0 else pDevice.service_data.keys()
    )
    if pDevice.name and _Device.Name==_Device.ID:
      _Device.Name = pDevice.name
    if not _Device: return
    if not _Device.Template: #No templates, cant be processed
      Bluetooth.Devices.Remove(_Device.ID)
      return
    if not any (x for x in self._Done if x.Device.ID==_Device.ID):
      self._Done.append(LibPython.Dynamic(Device=_Device,Signal=pDevice.rssi,ServiceData=pDevice.service_data))
      self.Logger.Debug(f'Detected:{_Device.ID}({_Device.Name})')
      if _Device.IsRegistered:
        _Device.BLEDevice = async_ble_device_from_address(LibHass.Hass,_Device.ID,connectable=_Device.Template.Connect)
        asyncio.run_coroutine_threadsafe(_Device.OnDetect(pDevice.rssi,pDevice.service_data),LibHass.MainLoop)
      else:
        _Device.Detected = datetime.now()
    return

  async def Run(self)->bool:
    self._Done=[]
    await asyncio.wait(self._Events,timeout=SCAN_INTERVAL,return_when=asyncio.FIRST_COMPLETED)
    for _Device in Bluetooth.Devices:
      if not _Device.IsRegistered and (datetime.now()-_Device.Detected).total_seconds()>Bluetooth.Device.ExpiryInterval:
        Bluetooth.Devices.Remove(_Device.ID) #Detected but too old
      elif _Device.IsRegistered and not _Device.Template.Connect and _Device.Refreshed>datetime.min and (datetime.now()-_Device.Refreshed).total_seconds()>_Device.ExpiryInterval:
        await _Device.Disconnect()
        _Device.Refreshed = datetime.min
    return True

_Instance = None
def Start():
  global _Instance
  if _Instance: _Instance.Stop()
  _Instance = Scanner()
  _Instance.Start()

def Stop():
  global _Instance
  if _Instance: _Instance.Stop()
  _Instance = None
  
