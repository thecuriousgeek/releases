import asyncio
import LibHass

class Entity(LibHass.Entity):
  def __init__(self,**kwargs):
    LibHass.Entity.__init__(self,**kwargs)
    self.Service = kwargs['Service'] if 'Service' in kwargs else None
    self.Characteristic = kwargs['Characteristic'] if 'Characteristic' in kwargs else None
    self.SubType = kwargs['SubType'] if 'SubType' in kwargs else None
    self.Unit = kwargs['Unit'] if 'Unit' in kwargs else None
    self.Code = kwargs['Code'] if 'Code' in kwargs else None
    self.Handle = None


class Sensor(Entity,LibHass.Sensor):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Sensor.__init__(self,**kwargs)


class BinarySensor(Entity,LibHass.BinarySensor):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.BinarySensor.__init__(self,**kwargs)


class Button(Entity,LibHass.Button):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Button.__init__(self,**kwargs)


class Switch(Entity,LibHass.Switch):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Switch.__init__(self,**kwargs)
  
  async def OnCommand(self,pCommand:bool):
    if self.Device and self.Device.IsConnected:
      asyncio.run_coroutine_threadsafe(self.OnValue(pCommand),LibHass.MainLoop)
      LibHass.MainLoop.run_in_executor(None,lambda:self.Device.Monitor.Client.write_gatt_char(self.Handle,self.Value.to_bytes(1,'big')))
    await LibHass.Switch.OnCommand(self,pCommand)


class Text(Entity,LibHass.Text):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Switch.__init__(self,**kwargs)

  async def OnCommand(self,pCommand:str):
    if self.Device and self.Device.IsConnected:
      asyncio.run_coroutine_threadsafe(self.OnValue(pCommand),LibHass.MainLoop)
      LibHass.MainLoop.run_in_executor(None,lambda:self.Device.Monitor.Client.write_gatt_char(self.Handle,bytes(self.Value)))
    await LibHass.Text.OnCommand(self,pCommand)


class Number(Entity,LibHass.Number):
  def __init__(self,**kwargs):
    Entity.__init__(self,**kwargs)
    LibHass.Switch.__init__(self,**kwargs)

  async def OnCommand(self,pCommand:int):
    if self.Device and self.Device.IsConnected:
      await self.OnValue(int(pCommand))
      LibHass.MainLoop.run_in_executor(None,lambda:self.Device.Monitor.Client.write_gatt_char(self.Handle,self.Value.to_bytes(1,'big')))
    await LibHass.Number.OnCommand(self,pCommand)
