import asyncio
import threading
from datetime import datetime,timedelta
import time
from types import SimpleNamespace
import LibHass
import Bluetooth

class Device(LibHass.Device):  
  Poll=None

  @staticmethod
  async def Remove(pID:str)->None:
    _Device =  Bluetooth.Devices.Get(pID)
    if _Device: 
      Bluetooth.Devices.remove(_Device)
    return

  @staticmethod
  async def GetOrCreate(**kwargs):
    _Device = Bluetooth.Devices.Get(kwargs['ID'])
    if not _Device: 
      _Device = Device(**kwargs)
      await Bluetooth.Template.Populate(_Device,_Device.SubType,_Device.Name,kwargs['Services'] if 'Services' in kwargs else None)
      Bluetooth.Devices.Add(_Device)
    return _Device

  def __init__(self,**kwargs):
    LibHass.Device.__init__(self,**kwargs)
    self.Monitor = None

  @property
  def IsConnected(self)->bool:
    if not self.Template.Connect: return (datetime.now()-self.Refreshed).total_seconds() < self.ExpiryInterval
    return self.Monitor is not None    

  async def OnDetect(self,pSignal:int,pData:dict[str:bytes])->None:
    _UpdatedEntities = await Bluetooth.Template.Parse(self,pData)
    await self.Entities.Get("SIGNAL").OnValue(pSignal)
    if not self.Template.Connect: 
      self.Logger.Debug(f'Updated:{len(_UpdatedEntities)} entities ({','.join(_UpdatedEntities)})')
      await LibHass.Device.OnRefresh(self)
    await LibHass.Device.OnDetect(self)

  async def Connect(self)->bool:
    if self.Monitor: return True #Already connected, or connectin in progress
    if not self.Template.Connect: return True #BLE device
    self.Monitor = Bluetooth.Monitor(self)
    self.Monitor.Start()
    return True

  async def Disconnect(self)->None:
    if self.Monitor: 
      asyncio.run_coroutine_threadsafe(self.Monitor.Disconnect(),self.Monitor.Loop)
    else:
      asyncio.run_coroutine_threadsafe(self.OnDisconnect(),LibHass.MainLoop)

  async def OnDisconnect(self)->None:
    # if self.Monitor: 
    #   self.Monitor.join()
    self.Monitor = None
    await LibHass.Device.OnDisconnect(self)

  async def Refresh(self):
    if self.Monitor: 
      asyncio.run_coroutine_threadsafe(self.Monitor.Refresh(),self.Monitor.Loop)
