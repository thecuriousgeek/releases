from datetime import datetime
import asyncio
from bleak import BleakScanner,BleakClient
import LibPython
import LibHass
import Bluetooth

SCAN_INTERVAL=10
class Scanner(LibPython.AsyncTask):
  _Events=None
  _Scanner=None
  _Done=[]

  def __init__(self):
    super().__init__('Bluetooth.BleakScanner')

  async def Begin(self):
    self._Scanner = BleakScanner(detection_callback=self.OnDetect,scanning_mode='active')
    self._Events = [asyncio.create_task(self.CommandStop.wait())]
    await self._Scanner.start()
    return True

  async def End(self):
    await self._Scanner.stop()
    return True

  def GetClient(pID:str,pOnDisconnect):
    return BleakClient(pID,disconnected_callback=pOnDisconnect,timeout=60)

  async def OnDetect(self,pDevice,pData)->None:
    _Device = await Bluetooth.Device.GetOrCreate(
              ID=pDevice.address,
              Name=pData.local_name or pDevice.address,
              Services=(pData.service_uuids if len(pData.service_uuids)>0 else pData.service_data.keys())
    )
    if pData.local_name and _Device.Name==_Device.ID:
      _Device.Name = pData.local_name
    if not _Device: return
    if not _Device.Template: #No templates, cant be processed
      Bluetooth.Devices.Remove(_Device.ID)
      return
    _Device.BLEDevice = pDevice
    if not any (x for x in self._Done if x.Device.ID==_Device.ID):
      self._Done.append(LibPython.Dynamic(Device=_Device,Signal=pData.rssi,ServiceData=pData.service_data))
      self.Logger.Debug(f'Detected:{_Device.ID}({_Device.Name})')
      if _Device.IsRegistered:
        asyncio.run_coroutine_threadsafe(_Device.OnDetect(pData.rssi,pData.service_data),LibHass.MainLoop)
      else:
        _Device.Detected = datetime.now()
    return

  async def Run(self)->bool:
    self._Done = []
    await asyncio.wait(self._Events,timeout=SCAN_INTERVAL,return_when=asyncio.FIRST_COMPLETED)
    for _Device in Bluetooth.Devices:
      if not _Device.IsRegistered and (datetime.now()-_Device.Detected).total_seconds()>Bluetooth.Device.ExpiryInterval:
        Bluetooth.Devices.Remove(_Device.ID) #Detected but too old
      elif _Device.IsRegistered and not _Device.Template.Connect and _Device.Refreshed>datetime.min and (datetime.now()-_Device.Refreshed).total_seconds()>_Device.ExpiryInterval:
        await _Device.Disconnect()
        _Device.Refreshed = datetime.min
    return True

_Instance = None
def Start():
  global _Instance
  if _Instance: _Instance.Stop()
  _Instance = Scanner()
  _Instance.Start()

def Stop():
  global _Instance
  if _Instance: _Instance.Stop()
  _Instance = None
