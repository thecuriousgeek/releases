import os
import json
import asyncio
import LibHass 
from .Device import Device
from .Entity import *
from .Template import Template
if LibHass.IS_ADDON:
  from . import HassScanner as Scanner
else:
  from . import BleakScanner as Scanner
from .Monitor import Monitor

Name='tcg-bluetooth'
ConfiguredDevices = LibHass.DeviceCollection()
Devices = LibHass.DeviceCollection()

async def Reload()->None:
  return

async def Restart()->None:
  Scanner.Stop()
  for d in Devices:
    if d.IsConnected: asyncio.run_coroutine_threadsafe(d.Disconnect(),LibHass.MainLoop)
  Scanner.Start()

async def Init():
  pass

def Configuration()->dict:
  _Result = {}
  _Devices = [{'ID':x.ID,'Name':x.Name,'SubType':x.SubType} for x in Devices if x.IsRegistered]
  #Because Im OCD
  _Result['Devices'] = sorted(_Devices, key=lambda i: i['Name'])
  return _Result

async def Configure(pData:dict)->None:
  if not pData:
    pData = await LoadConfig()
    if not pData: raise 'No configuration found'
  ConfiguredDevices.clear()
  for d in pData['Devices'] or [] if 'Devices' in pData else []:
    await Device.Remove(d['ID'])
    _Device = await Device.GetOrCreate(**d)
    ConfiguredDevices.Add(_Device)
    _Device.IsRegistered = True
  
async def LoadConfig()->dict:
  if not os.path.exists('config.json'): return
  _Data = json.load(open('config.json','r'))
  return _Data

async def Save():
  _Devices = Configuration()
  s = json.dumps(_Devices,default=lambda o: o.__dict__,indent=2)
  open('config.json','w').write(s)

def Add(pDevice)->bool:
  pDevice.IsRegistered = True
  Save()

def Remove(pDevice)->bool:
  pDevice.IsRegistered = False
  Save()

def Save():
  _Devices = Configuration()
  s = json.dumps(_Devices,default=lambda o: o.__dict__,indent=2)
  open('config.json','w').write(s)
 
