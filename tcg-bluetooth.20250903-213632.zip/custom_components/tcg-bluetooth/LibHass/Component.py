import asyncio
import LibPython
import LibHass

Logger = LibPython.Logger('Component')
async def Init(hass=None):
  LibHass.MainLoop = asyncio.get_running_loop()
  LibHass.Hass = hass
  pass

if LibHass.IS_ADDON:
  from homeassistant.helpers import discovery
  from homeassistant.helpers import device_registry,entity_registry
  from homeassistant.config_entries import ConfigEntry,ConfigEntryState,ConfigEntryDisabler
  import  homeassistant.config_entries
  __FirstTime = True
  #For entries in configuration.yaml
  async def async_setup(hass, config):
    #asyncio.ensure_future(main(),loop=_Loop)
    Logger.Debug(f'async_setup:{config}')
    global __FirstTime
    if __FirstTime:
      __FirstTime = False
      global Hass,MainLoop
      Hass = hass
      MainLoop = asyncio.get_event_loop()
    return True

  async def async_migrate_entry(hass, entry):
    Logger.Debug(f'async_migrate_entry:{entry.unique_id}')
    return True

  #For entries in .storage/core.config_entries
  async def async_setup_entry(hass,platform,entry):
    Logger.Debug(f'async_setup_entry:{entry.title} - {str(entry.data)} [{str(entry.options)}]')
    _Data = dict(entry.data)
    #_Data['Name'] = entry.title
    _Data['Devices'] = entry.options['Devices'] if 'Devices' in entry.options else None
    await platform.Configure(_Data)
    await AddDevices([d for d in platform.Devices if d.IsRegistered],entry)
    entry.async_on_unload(entry.add_update_listener(update_listener))
    return True

  async def update_listener(hass,entry):
    Logger.Debug(f'update_listener:{entry.title}({str(entry.data)})')
    await hass.config_entries.async_reload(entry.entry_id)

  async def async_unload_entry(hass,platform,entry)->bool:
    Logger.Debug(f'async_unload_entry:{str(entry.data)}')
    for _Device in platform.Devices:
      _Device.IsRegistered = False
      if _Device.IsConnected: await _Device.Disconnect()
      await DelDevice(_Device,entry)
      #Manager.Devices.Remove(_Device.ID)
    for p in ['sensor','binary_sensor','switch','button','number','text']:
      try: await hass.config_entries.async_forward_entry_unload(entry,p)
      except: pass
    return True

  async def AddDevices(pDevices,pEntry)->bool:
    dr = device_registry.async_get(Hass)
    er = entity_registry.async_get(Hass)
    for _Device in pDevices:
      _Device.Logger.Info(f'Adding to HASS')
      d = dr.async_get_or_create(
          config_entry_id=pEntry.entry_id,
          connections={},
          identifiers={('TheCuriousGeek',f'{_Device.FullName.replace(" ","_")}')},
          name=_Device.Name,
          manufacturer="SV Anand",
          model=_Device.Type
          )
      _Device.DeviceID = d.id
    pEntry.Devices = pDevices
    await Hass.config_entries.async_forward_entry_setups(pEntry,['sensor','binary_sensor','switch','button','number','text'])
    for _Device in pDevices:
      for e in _Device.Entities:
        e.InHass = True
        er.async_update_entity(entity_id=e.entity_id,device_id=e.Device.DeviceID)
        if not e.Enabled: er.async_update_entity(entity_id=e.entity_id,disabled_by=entity_registry.RegistryEntryDisabler.USER)
        await e.RestoreState()

  async def DelDevice(pDevice,pEntry)->bool:
    try:
      dr = device_registry.async_get(Hass)
      er = entity_registry.async_get(Hass)
      if dr.async_get(pDevice.DeviceID):
        d = dr.async_remove_device(pDevice.DeviceID)
        pDevice.Logger.Info(f'Removed from HASS')
        for e in pDevice.Entities:
          e.InHass = False
    except:
      pDevice.Logger.Error(f'Error removing from HASS')
      pass
    return True
